export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'user';
  balance: number;
  createdAt: string;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  stock: number;
  category: string;
}

export interface Consumption {
  id: number;
  userId: number;
  productId: number;
  productName: string;
  quantity: number;
  totalPrice: number;
  date: string;
}

export interface Table {
  id: number;
  name: string;
  description?: string;
}

export interface Reservation {
  id: number;
  userId: number;
  userName: string;
  tableId: number;
  tableName: string;
  startTime: string;
  endTime: string;
  status: 'active' | 'cancelled' | 'completed';
}

export interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  loading: boolean;
}