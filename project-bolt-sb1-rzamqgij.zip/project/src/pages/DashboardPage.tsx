import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Calendar, ShoppingCart, CreditCard, Clock, MapPin } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Reservation, Consumption } from '../types';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [consumptions, setConsumptions] = useState<Consumption[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API calls - replace with actual API calls
    const fetchData = async () => {
      try {
        // Mock data - replace with actual API calls
        setReservations([
          {
            id: 1,
            userId: 1,
            userName: user?.name || '',
            tableId: 1,
            tableName: 'Mesa Principal',
            startTime: '2025-01-15T16:00:00',
            endTime: '2025-01-15T20:00:00',
            status: 'active'
          },
          {
            id: 2,
            userId: 1,
            userName: user?.name || '',
            tableId: 2,
            tableName: 'Mesa Warhammer',
            startTime: '2025-01-18T14:00:00',
            endTime: '2025-01-18T18:00:00',
            status: 'active'
          }
        ]);

        setConsumptions([
          {
            id: 1,
            userId: 1,
            productId: 1,
            productName: 'Coca Cola',
            quantity: 2,
            totalPrice: 4.00,
            date: '2025-01-10T15:30:00'
          },
          {
            id: 2,
            userId: 1,
            productId: 2,
            productName: 'Patatas Fritas',
            quantity: 1,
            totalPrice: 2.50,
            date: '2025-01-10T16:00:00'
          }
        ]);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const stats = [
    {
      icon: <Calendar className="w-6 h-6" />,
      label: 'Reservas Activas',
      value: reservations.filter(r => r.status === 'active').length,
      color: 'text-primary-500'
    },
    {
      icon: <ShoppingCart className="w-6 h-6" />,
      label: 'Consumos del Mes',
      value: consumptions.length,
      color: 'text-secondary-500'
    },
    {
      icon: <CreditCard className="w-6 h-6" />,
      label: 'Saldo Actual',
      value: `€${user?.balance || 0}`,
      color: 'text-green-500'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-dark-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-950 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Bienvenido de vuelta, {user?.name}
          </p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6">
                <div className="flex items-center">
                  <div className={`${stat.color} mr-4`}>
                    {stat.icon}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {stat.label}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {stat.value}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Reservations */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Próximas Reservas
                </h2>
                <Calendar className="w-5 h-5 text-gray-500" />
              </div>
              
              {reservations.length > 0 ? (
                <div className="space-y-4">
                  {reservations.slice(0, 3).map((reservation) => (
                    <div
                      key={reservation.id}
                      className="flex items-center justify-between p-4 bg-gray-50 dark:bg-dark-800 rounded-lg"
                    >
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 text-primary-500 mr-3" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            {reservation.tableName}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {format(new Date(reservation.startTime), 'PPp', { locale: es })}
                          </p>
                        </div>
                      </div>
                      <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full">
                        Activa
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                  No tienes reservas activas
                </p>
              )}
            </Card>
          </motion.div>

          {/* Recent Consumptions */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Consumos Recientes
                </h2>
                <ShoppingCart className="w-5 h-5 text-gray-500" />
              </div>
              
              {consumptions.length > 0 ? (
                <div className="space-y-4">
                  {consumptions.slice(0, 3).map((consumption) => (
                    <div
                      key={consumption.id}
                      className="flex items-center justify-between p-4 bg-gray-50 dark:bg-dark-800 rounded-lg"
                    >
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">
                          {consumption.productName}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Cantidad: {consumption.quantity}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900 dark:text-white">
                          €{consumption.totalPrice.toFixed(2)}
                        </p>
                        <p className="text-xs text-gray-500">
                          {format(new Date(consumption.date), 'dd/MM/yyyy')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                  No hay consumos recientes
                </p>
              )}
            </Card>
          </motion.div>
        </div>

        {/* Profile Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Información del Perfil
              </h2>
              <User className="w-5 h-5 text-gray-500" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Nombre
                </label>
                <p className="text-gray-900 dark:text-white">{user?.name}</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Email
                </label>
                <p className="text-gray-900 dark:text-white">{user?.email}</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Rol
                </label>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  user?.role === 'admin' 
                    ? 'bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200'
                    : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                }`}>
                  {user?.role === 'admin' ? 'Administrador' : 'Usuario'}
                </span>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Miembro desde
                </label>
                <p className="text-gray-900 dark:text-white">
                  {user?.createdAt ? format(new Date(user.createdAt), 'MMMM yyyy', { locale: es }) : 'N/A'}
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};