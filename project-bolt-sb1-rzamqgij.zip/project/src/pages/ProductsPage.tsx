import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Coffee, Package, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Product } from '../types';

export const ProductsPage: React.FC = () => {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<Record<number, number>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        // Mock data - replace with actual API call
        setProducts([
          { id: 1, name: 'Coca Cola', price: 2.00, stock: 50, category: 'Bebidas' },
          { id: 2, name: 'Pepsi', price: 2.00, stock: 30, category: 'Bebidas' },
          { id: 3, name: 'Agua', price: 1.50, stock: 40, category: 'Bebidas' },
          { id: 4, name: 'Café', price: 1.80, stock: 25, category: 'Bebidas' },
          { id: 5, name: 'Patatas Fritas', price: 2.50, stock: 20, category: 'Snacks' },
          { id: 6, name: 'Galletas', price: 1.80, stock: 15, category: 'Snacks' },
          { id: 7, name: 'Chocolate', price: 2.20, stock: 18, category: 'Snacks' },
          { id: 8, name: 'Frutos Secos', price: 3.00, stock: 12, category: 'Snacks' },
        ]);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const addToCart = (productId: number) => {
    setCart(prev => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1
    }));
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => {
      const newCart = { ...prev };
      if (newCart[productId] > 1) {
        newCart[productId]--;
      } else {
        delete newCart[productId];
      }
      return newCart;
    });
  };

  const getTotalPrice = () => {
    return Object.entries(cart).reduce((total, [productId, quantity]) => {
      const product = products.find(p => p.id === parseInt(productId));
      return total + (product ? product.price * quantity : 0);
    }, 0);
  };

  const handlePurchase = async () => {
    if (!user || Object.keys(cart).length === 0) return;

    try {
      // Mock purchase - replace with actual API call
      console.log('Processing purchase:', cart);
      setCart({});
      // Show success message
    } catch (error) {
      console.error('Error processing purchase:', error);
    }
  };

  const categories = ['Bebidas', 'Snacks'];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-dark-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-950 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Productos & Consumibles
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Disfruta de refrescos y snacks mientras juegas
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Products */}
          <div className="lg:col-span-3">
            {categories.map((category) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="mb-8"
              >
                <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                  {category === 'Bebidas' ? <Coffee className="w-6 h-6 mr-2" /> : <Package className="w-6 h-6 mr-2" />}
                  {category}
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products
                    .filter(product => product.category === category)
                    .map((product) => (
                      <Card key={product.id} className="p-6" hover>
                        <div className="text-center">
                          <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mx-auto mb-4">
                            {category === 'Bebidas' ? (
                              <Coffee className="w-8 h-8 text-primary-600" />
                            ) : (
                              <Package className="w-8 h-8 text-primary-600" />
                            )}
                          </div>
                          
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                            {product.name}
                          </h3>
                          
                          <p className="text-2xl font-bold text-primary-600 mb-2">
                            €{product.price.toFixed(2)}
                          </p>
                          
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                            Stock: {product.stock} unidades
                          </p>

                          <div className="flex items-center justify-center space-x-2">
                            {cart[product.id] > 0 && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => removeFromCart(product.id)}
                                >
                                  -
                                </Button>
                                <span className="px-3 py-1 bg-gray-100 dark:bg-dark-800 rounded text-sm font-medium">
                                  {cart[product.id]}
                                </span>
                              </>
                            )}
                            
                            <Button
                              size="sm"
                              onClick={() => addToCart(product.id)}
                              disabled={!user || product.stock === 0}
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              {cart[product.id] > 0 ? 'Añadir' : 'Agregar'}
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Cart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-1"
          >
            <Card className="p-6 sticky top-24">
              <div className="flex items-center mb-4">
                <ShoppingCart className="w-5 h-5 text-primary-500 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Mi Carrito
                </h2>
              </div>

              {Object.keys(cart).length > 0 ? (
                <>
                  <div className="space-y-3 mb-4">
                    {Object.entries(cart).map(([productId, quantity]) => {
                      const product = products.find(p => p.id === parseInt(productId));
                      if (!product) return null;

                      return (
                        <div key={productId} className="flex items-center justify-between text-sm">
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">
                              {product.name}
                            </p>
                            <p className="text-gray-600 dark:text-gray-400">
                              {quantity} × €{product.price.toFixed(2)}
                            </p>
                          </div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            €{(product.price * quantity).toFixed(2)}
                          </p>
                        </div>
                      );
                    })}
                  </div>

                  <div className="border-t border-gray-200 dark:border-dark-700 pt-4 mb-4">
                    <div className="flex items-center justify-between text-lg font-semibold">
                      <span className="text-gray-900 dark:text-white">Total:</span>
                      <span className="text-primary-600">€{getTotalPrice().toFixed(2)}</span>
                    </div>
                  </div>

                  <Button
                    onClick={handlePurchase}
                    disabled={!user}
                    className="w-full"
                  >
                    Procesar Compra
                  </Button>

                  {!user && (
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-2 text-center">
                      Inicia sesión para realizar compras
                    </p>
                  )}
                </>
              ) : (
                <div className="text-center py-8">
                  <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Tu carrito está vacío
                  </p>
                </div>
              )}

              {user && (
                <div className="mt-6 pt-4 border-t border-gray-200 dark:border-dark-700">
                  <div className="text-sm text-center">
                    <p className="text-gray-600 dark:text-gray-400">Saldo actual:</p>
                    <p className="text-lg font-semibold text-green-600">
                      €{user.balance?.toFixed(2) || '0.00'}
                    </p>
                  </div>
                </div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};