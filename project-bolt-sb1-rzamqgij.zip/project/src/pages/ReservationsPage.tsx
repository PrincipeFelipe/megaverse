import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, MapPin, Plus, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Input } from '../components/ui/Input';
import { Table, Reservation } from '../types';
import { format, addDays, startOfWeek, isSameDay, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export const ReservationsPage: React.FC = () => {
  const { user } = useAuth();
  const [tables, setTables] = useState<Table[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [selectedWeek, setSelectedWeek] = useState(new Date());
  const [showModal, setShowModal] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{
    tableId: number;
    date: Date;
    hour: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  const timeSlots = Array.from({ length: 12 }, (_, i) => i + 10); // 10:00 to 21:00

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Mock data - replace with actual API calls
        setTables([
          { id: 1, name: 'Mesa Principal', description: 'Mesa grande para 6-8 jugadores' },
          { id: 2, name: 'Mesa Warhammer', description: 'Mesa especializada para Warhammer 40K' },
          { id: 3, name: 'Mesa Privada', description: 'Mesa íntima para 2-4 jugadores' },
        ]);

        setReservations([
          {
            id: 1,
            userId: 1,
            userName: 'Usuario Test',
            tableId: 1,
            tableName: 'Mesa Principal',
            startTime: '2025-01-15T16:00:00',
            endTime: '2025-01-15T20:00:00',
            status: 'active'
          },
          {
            id: 2,
            userId: 2,
            userName: 'Otro Usuario',
            tableId: 2,
            tableName: 'Mesa Warhammer',
            startTime: '2025-01-16T14:00:00',
            endTime: '2025-01-16T18:00:00',
            status: 'active'
          }
        ]);
      } catch (error) {
        console.error('Error fetching reservations data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const getWeekDays = () => {
    const weekStart = startOfWeek(selectedWeek, { weekStartsOn: 1 });
    return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  };

  const isSlotReserved = (tableId: number, date: Date, hour: number) => {
    return reservations.some(reservation => {
      const startTime = parseISO(reservation.startTime);
      const endTime = parseISO(reservation.endTime);
      const slotTime = new Date(date);
      slotTime.setHours(hour, 0, 0, 0);
      
      return reservation.tableId === tableId &&
             isSameDay(startTime, date) &&
             slotTime >= startTime &&
             slotTime < endTime;
    });
  };

  const handleSlotClick = (tableId: number, date: Date, hour: number) => {
    if (!user) return;
    
    if (isSlotReserved(tableId, date, hour)) return;
    
    setSelectedSlot({ tableId, date, hour });
    setShowModal(true);
  };

  const handleReservation = async () => {
    if (!selectedSlot || !user) return;

    try {
      // Mock reservation creation - replace with actual API call
      const newReservation: Reservation = {
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        tableId: selectedSlot.tableId,
        tableName: tables.find(t => t.id === selectedSlot.tableId)?.name || '',
        startTime: new Date(selectedSlot.date.setHours(selectedSlot.hour)).toISOString(),
        endTime: new Date(selectedSlot.date.setHours(selectedSlot.hour + 2)).toISOString(),
        status: 'active'
      };

      setReservations(prev => [...prev, newReservation]);
      setShowModal(false);
      setSelectedSlot(null);
    } catch (error) {
      console.error('Error creating reservation:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-dark-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-950 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Sistema de Reservas
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Reserva tu mesa favorita para tus partidas épicas
          </p>
        </motion.div>

        {/* Week Navigation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={() => setSelectedWeek(addDays(selectedWeek, -7))}
              >
                ← Semana Anterior
              </Button>
              
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                {format(selectedWeek, 'MMMM yyyy', { locale: es })}
              </h2>
              
              <Button
                variant="outline"
                onClick={() => setSelectedWeek(addDays(selectedWeek, 7))}
              >
                Semana Siguiente →
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Reservation Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-6 overflow-x-auto">
            <div className="min-w-[800px]">
              {/* Header with days */}
              <div className="grid grid-cols-8 gap-2 mb-4">
                <div className="font-semibold text-gray-900 dark:text-white">Mesa</div>
                {getWeekDays().map((day) => (
                  <div key={day.toISOString()} className="text-center">
                    <div className="font-semibold text-gray-900 dark:text-white">
                      {format(day, 'EEE', { locale: es })}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {format(day, 'dd/MM')}
                    </div>
                  </div>
                ))}
              </div>

              {/* Tables and time slots */}
              {tables.map((table) => (
                <div key={table.id} className="mb-6">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                    {table.name}
                  </h3>
                  
                  {/* Time slots grid */}
                  <div className="grid grid-cols-8 gap-2">
                    <div className="flex flex-col space-y-1">
                      {timeSlots.map((hour) => (
                        <div key={hour} className="h-8 flex items-center text-sm text-gray-600 dark:text-gray-400">
                          {hour}:00
                        </div>
                      ))}
                    </div>
                    
                    {getWeekDays().map((day) => (
                      <div key={day.toISOString()} className="flex flex-col space-y-1">
                        {timeSlots.map((hour) => {
                          const isReserved = isSlotReserved(table.id, day, hour);
                          const isPast = new Date() > new Date(day.setHours(hour));
                          
                          return (
                            <button
                              key={hour}
                              onClick={() => handleSlotClick(table.id, day, hour)}
                              disabled={isReserved || isPast || !user}
                              className={`
                                h-8 rounded text-xs font-medium transition-colors
                                ${isReserved 
                                  ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 cursor-not-allowed'
                                  : isPast
                                  ? 'bg-gray-100 text-gray-400 dark:bg-dark-800 dark:text-gray-600 cursor-not-allowed'
                                  : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 hover:bg-green-200 dark:hover:bg-green-800 cursor-pointer'
                                }
                              `}
                            >
                              {isReserved ? 'Ocupado' : isPast ? 'Pasado' : 'Libre'}
                            </button>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* User's Reservations */}
        {user && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-8"
          >
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Mis Reservas
              </h2>
              
              {reservations.filter(r => r.userId === user.id).length > 0 ? (
                <div className="space-y-4">
                  {reservations
                    .filter(r => r.userId === user.id)
                    .map((reservation) => (
                      <div
                        key={reservation.id}
                        className="flex items-center justify-between p-4 bg-gray-50 dark:bg-dark-800 rounded-lg"
                      >
                        <div className="flex items-center">
                          <MapPin className="w-5 h-5 text-primary-500 mr-3" />
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">
                              {reservation.tableName}
                            </p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {format(new Date(reservation.startTime), 'PPp', { locale: es })}
                            </p>
                          </div>
                        </div>
                        <span className="px-3 py-1 text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full">
                          {reservation.status === 'active' ? 'Activa' : 'Completada'}
                        </span>
                      </div>
                    ))}
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                  No tienes reservas activas
                </p>
              )}
            </Card>
          </motion.div>
        )}

        {/* Reservation Modal */}
        <Modal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          title="Confirmar Reserva"
        >
          {selectedSlot && (
            <div className="space-y-4">
              <p className="text-gray-600 dark:text-gray-400">
                ¿Deseas reservar la siguente mesa?
              </p>
              
              <div className="bg-gray-50 dark:bg-dark-800 p-4 rounded-lg">
                <p className="font-medium text-gray-900 dark:text-white">
                  {tables.find(t => t.id === selectedSlot.tableId)?.name}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {format(selectedSlot.date, 'PPP', { locale: es })}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedSlot.hour}:00 - {selectedSlot.hour + 2}:00 (2 horas)
                </p>
              </div>
              
              <div className="flex space-x-3">
                <Button onClick={handleReservation} className="flex-1">
                  Confirmar Reserva
                </Button>
                <Button variant="outline" onClick={() => setShowModal(false)} className="flex-1">
                  Cancelar
                </Button>
              </div>
            </div>
          )}
        </Modal>
      </div>
    </div>
  );
};