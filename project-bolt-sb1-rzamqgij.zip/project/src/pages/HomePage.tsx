import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Sword, Users, Calendar, Trophy, Coffee, Shield } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';

export const HomePage: React.FC = () => {
  const features = [
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Comunidad Gaming',
      description: 'Únete a nuestra comunidad de jugadores apasionados por los juegos de mesa y wargames.',
    },
    {
      icon: <Calendar className="w-8 h-8" />,
      title: 'Sistema de Reservas',
      description: 'Reserva tu mesa favorita para tus partidas épicas de Warhammer 40K y otros juegos.',
    },
    {
      icon: <Coffee className="w-8 h-8" />,
      title: 'Productos & Snacks',
      description: 'Disfruta de refrescos y snacks mientras juegas. Sistema de consumo integrado.',
    },
    {
      icon: <Trophy className="w-8 h-8" />,
      title: 'Torneos & Eventos',
      description: 'Participa en torneos organizados y eventos especiales para la comunidad.',
    },
  ];

  const stats = [
    { number: '150+', label: 'Miembros Activos' },
    { number: '3', label: 'Mesas de Juego' },
    { number: '50+', label: 'Juegos Disponibles' },
    { number: '24/7', label: 'Disponibilidad' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950">
      {/* Hero Section */}
      <section className="relative px-4 py-20 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="flex justify-center mb-8"
            >
              <div className="p-4 bg-primary-600 rounded-full">
                <Sword className="w-16 h-16 text-white" />
              </div>
            </motion.div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Bienvenido a{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-secondary-500">
                MEGAVERSE
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              La asociación de ocio definitiva para los amantes de los juegos de mesa, wargames y especialmente Warhammer 40.000. 
              Únete a nuestra comunidad y vive experiencias épicas.
            </p>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to="/auth">
                <Button size="lg" className="min-w-[200px]">
                  <Shield className="w-5 h-5 mr-2" />
                  Únete Ahora
                </Button>
              </Link>
              <Link to="/reservations">
                <Button variant="outline" size="lg" className="min-w-[200px]">
                  <Calendar className="w-5 h-5 mr-2" />
                  Ver Reservas
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>

        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{ 
              rotate: 360,
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute top-20 left-10 w-20 h-20 border-2 border-primary-500/20 rounded-full"
          />
          <motion.div
            animate={{ 
              rotate: -360,
              scale: [1, 0.9, 1]
            }}
            transition={{ 
              duration: 25,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute bottom-20 right-10 w-32 h-32 border-2 border-secondary-500/20 rounded-full"
          />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              ¿Por qué elegir MEGAVERSE?
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Ofrecemos la mejor experiencia gaming con instalaciones de primera y una comunidad increíble.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card hover className="p-6 h-full text-center">
                  <div className="text-primary-500 mb-4 flex justify-center">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-400">
                    {feature.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-dark-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-bold text-primary-500 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-300 font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              ¿Listo para la batalla?
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Únete a MEGAVERSE y forma parte de la mejor comunidad gaming. 
              Reserva tu primera mesa y comienza tu aventura épica.
            </p>
            <Link to="/auth">
              <Button size="lg" className="min-w-[250px]">
                <Shield className="w-5 h-5 mr-2" />
                Comenzar Ahora
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};