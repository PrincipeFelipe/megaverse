import React from 'react';
import { Sword } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-950 border-t border-dark-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sword className="w-6 h-6 text-primary-500" />
            <span className="text-lg font-semibold text-white">MEGAVERSE</span>
          </div>
          <p className="text-gray-400 text-sm">
            © 2025 MEGAVERSE. Asociación de ocio y gaming.
          </p>
        </div>
        <div className="mt-4 text-center text-gray-500 text-sm">
          <p>Especialistas en juegos de mesa, wargames y Warhammer 40.000</p>
        </div>
      </div>
    </footer>
  );
};